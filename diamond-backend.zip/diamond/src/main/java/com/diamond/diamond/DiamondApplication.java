package com.diamond.diamond;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiamondApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiamondApplication.class, args);
	}

}
