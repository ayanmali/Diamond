package com.diamond.diamond;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiamondApplicationTests {

	@Test
	void contextLoads() {
	}

}
